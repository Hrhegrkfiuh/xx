export PATH=/usr/local/mysql/bin:$PATH
